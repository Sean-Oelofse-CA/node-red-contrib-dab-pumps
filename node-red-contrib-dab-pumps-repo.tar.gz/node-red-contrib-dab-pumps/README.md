# node-red-contrib-dab-pumps

Node-RED nodes for **DAB Pumps** via the DConnect / DAB Live cloud API
(EsyBox, EsyBox Mini/Max, DConnect Box, and similar). Ported from the
[ankohanse/hass-dab-pumps](https://github.com/ankohanse/hass-dab-pumps)
Home Assistant integration and the original DConnect reverse-engineering.

This is a **cloud** client (like the app and the HA integration) — there is no
local/Modbus access. It logs into DAB's servers and reads device status.

## Nodes

- **DAB Pumps account** (config): stores your email/password (encrypted by
  Node-RED) and the API host.
- **DAB Pumps** (poll): logs in, lists your installation's devices, and outputs
  each device's live status. Polls on a timer and/or on any input message.

## Install

Requires **Node.js 18+** (uses the built-in `fetch`) and Node-RED 3.0+.

From your Node-RED user directory (`~/.node-red`, or `/config` on Home Assistant OS):

```bash
npm install node-red-contrib-dab-pumps-0.1.0.tgz
```

Then restart Node-RED. The **DAB Pumps** node appears under the *network* category.

## Use

1. Drag in a **DAB Pumps** node, open it, add a new **account** with your
   DAB email + password.
2. Set the poll interval (seconds; `0` = poll only when it receives input).
3. Wire the output to a debug node, an **MQTT out** node
   (`topic` is preset to `dabpumps/<serial>`), or the Home Assistant nodes.

### Output

`msg.payload` is the device's key/value status map, for example:

| key | meaning |
|-----|---------|
| `VP_PressureBar` | outlet pressure ×10 (25 → 2.5 bar) |
| `VF_FlowLiter` | flow ×10 |
| `PumpStatus` | 1 = running |
| `TE_HeatsinkTemperatureC` | heatsink temperature |

Exact keys depend on your pump model. Add a function/change node downstream to
scale and rename the fields you care about.

## Notes / limitations

- **Use a dedicated DAB account** for Node-RED; DConnect/H2D dislike concurrent
  logins from the same account.
- The verified login path is **DConnect**. Pumps that only speak the newer
  H2D / DAB Live token backend may need the login step swapped for the
  token endpoint.
- Read-only. Writing setpoints is not implemented in this version.

## License

MIT. Not affiliated with or endorsed by DAB Pumps.
